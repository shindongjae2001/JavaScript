setTimeout(() => {
    console.log("반갑습니다.");
}, 5000)  // 5초 후에 함수 실행